

export default function Customers(){
    return <h1>Customers</h1>
}