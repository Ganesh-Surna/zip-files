import classes from "./Home.module.css";

export default function Home(){
    return <div className={classes.home}>
        <h1>Welcome To React Shopping</h1>
        <p>Explore Amazing Designs!</p>
    </div>
}